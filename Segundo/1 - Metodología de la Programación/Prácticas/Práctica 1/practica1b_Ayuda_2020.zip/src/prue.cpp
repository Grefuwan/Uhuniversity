#include "prue.h"

prue::prue()
{
    //ctor
}

prue::~prue()
{
    //dtor
}
