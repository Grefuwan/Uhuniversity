#include <iostream>
#include "complejo.h"

using namespace std;

int main()
{
    const complejo a(2,-3);
    complejo b(-4,5),c(8,8);
    a.ver();
    b.ver();
    b.set();
    b.set(7,9);
    a.ver();
    b.ver();
    cout << "parte real de a: " << a.getr() << endl;
    cout << "parte imaginaria de a: " << a.geti() << endl;

    int x,y;
    x+y;
    c=b+a;
    c=a+b;
    c.ver();
    c=a+8;
    c.ver();
    c=8+a;
    c.ver();
    c=-a;
    c.ver();
    return 0;
}
