package libClases;

public interface Proceso {
	public abstract boolean equals(Object obj);	//True si son iguales
	void ver();	//Muestra en pantalla el objeto
}