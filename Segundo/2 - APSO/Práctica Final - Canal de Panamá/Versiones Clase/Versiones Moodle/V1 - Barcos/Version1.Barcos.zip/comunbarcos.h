#include <sys/types.h>
#include <sys/ipc.h>

int crea_cola(key_t clave);
void visualiza(int cola, int donde, int que, int como);
void R10();
void R12();


