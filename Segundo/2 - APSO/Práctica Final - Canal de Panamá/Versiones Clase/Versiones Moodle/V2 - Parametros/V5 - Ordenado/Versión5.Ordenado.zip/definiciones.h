/**** DECLARACION DE CONSTANTES ********************/
#define MAXVOESTEIN 45
#define MAXVESTEIN 45
#define MAXVOESTEOUT 45
#define MAXVESTEOUT 45
#define MAXVESCLUSAOESTE 1
#define MAXVESCLUSAESTE 1
#define MAXVLAGOE 8
#define MAXVLAGOO 8
#define MAXVHORNOS 36


#define COLOR_MAR 1
#define COLOR_MAR2 2
#define COLOR_FONDO 3
#define COLOR_BARCOE 4
#define COLOR_BARCOO 5


//informacion que se almacena de cada cliente
struct cliente{
 int elpid;
 int cualidad;
}; 


