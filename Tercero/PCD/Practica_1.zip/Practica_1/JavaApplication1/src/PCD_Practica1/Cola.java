package PCD_Practica1;

public class Cola implements ICola {

    int head;
    int tail;
    int capacidad;  //Capacidad del vector
    int numElementos = 0;   //Numero de Elementos que hay
    Object[] datos;

    public Cola(int capacidad) {    //Constructor
        //Inicializa la cola y los atributos de la clase
        this.head = 0;
        this.tail = 0;
        this.capacidad = capacidad;
        this.datos = new Object[capacidad];
        for (int i = 0; i < capacidad; i++) {
            this.datos[i] = 0;
        }
    }

    @Override
    public int getNum() {
        return this.numElementos;
    }

    @Override
    public void Acola(Object elemento) throws Exception {
        //Comprueba si la Cola no está llena, mientras no esté llena
        //Si no lo está, añade elemento
        if (colallena()) {
            throw new Exception("Error Acola: Cola Llena");
        }
        datos[tail] = elemento;
        numElementos++;
        tail = ++tail % capacidad;

    }

    public Object Desacola() throws Exception {
        //Comprueba que existan elementos, busca el primero y lo extrae
        if (colavacia()) {
            throw new Exception("Error Desacola: Cola Vacia");
        }
        Object obj = datos[head];
        datos[head] = 0;
        numElementos--;
        head = ++head % capacidad;

        return obj;
    }

    public Object Primero() throws Exception {
        //Comprueba que existan elementos, busca el primero y lo extrae
        if (colavacia()) {
            throw new Exception("Error Primero: Cola Vacia");
        }
        return datos[head];

    }

    public boolean colavacia() {
        if (this.numElementos == 0) {
            return true;
        } else {
            return false;
        }
    }

    public boolean colallena() {
        return this.numElementos == this.capacidad;
    }

    @Override
    public String toString() {
        String str = "";
        int i = 0;
        int tamano = datos.length;
        while (i < tamano) {
            if (!datos[i].equals(0)) {
                str += " - " + datos[i].toString() + " - ";
            } else {
                str += " - ~ - ";
            }
            i++;
        }
        return str;

    }

}
