package PCD_Practica1;

public class UsaCola {

    public static void main(String[] args) throws Exception {

        int tamaño = 4;
        Cola col = new Cola(tamaño);

        for (int i = 1; i <= 25; i++) {
            int j = (int) Math.round(Math.random());
            if (j == 0) {
                col.Acola(i);
                System.out.println("Acola: " + i);
                System.out.println("Cola: " + col.toString() + "\n");

            } else {
                col.Desacola();
                System.out.println("Desacola: " + i);
                System.out.println("Cola: " + col.toString() + "\n");

            }
        }

        System.out.println("Cola: " + col.toString());

    }

}
