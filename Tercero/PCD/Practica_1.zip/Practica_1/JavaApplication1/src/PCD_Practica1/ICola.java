package PCD_Practica1;

public interface ICola {

    public int getNum();

    public void Acola(Object elemento) throws Exception;

    public Object Desacola() throws Exception;

    public Object Primero() throws Exception;

}
