package proyecto_1;

import java.util.Random;


public class Perro extends Thread {

    private final int id;
    private final Comedero com;

    private Random r = new Random();

    public Perro(int id, Comedero com) {
        this.id = id;
        this.com = com;
    }

   

    @Override
    public void run() {
        try {
            r.setSeed(System.currentTimeMillis());

            //Entra Perro a Comer
            com.entraPerro();
            System.out.println("Perro " + id + " entra a comer ");

            //Come durante 1-3 segs
            sleep((r.nextInt(3) + 1) * 1000);

            //Sale Perro de comer
            com.salePerro();
            System.out.println("Perro " + id + " se va");
            
        } catch (InterruptedException ex) {
            
        }

    }
}
