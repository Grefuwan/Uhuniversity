package proyecto_1;

import static java.lang.Thread.sleep;
import java.util.Random;

public class Gato implements Runnable {

    private final int id;
    private final Comedero com;

    private Random r = new Random();

    public Gato(int id, Comedero com) {
        this.id = id;
        this.com = com;
    }

    @Override
    public void run() {
        try {
            r.setSeed(System.currentTimeMillis());

            //Entra Gato a Comer
            com.entraGato();
            System.out.println("Gato " + id + " entra a comer ");

            //Come durante 1-3 segs
            sleep((r.nextInt(3) + 1) * 1000);

            //Sale Gato de comer
            com.saleGato();
            System.out.println("Gato " + id + " se va");

        } catch (InterruptedException ex) {

        }
    }

}
