package proyecto_1;

public class Comedero {

    int numPerros = 0, numGatos = 0;

    public synchronized void entraPerro() throws InterruptedException {
        while ((numPerros == 3 && numGatos == 1) || (numPerros == 1 && numGatos == 3)) {
            wait();
        }
        numPerros++;
    }

    public synchronized void salePerro() {
        numPerros--;
        notifyAll();
    }

    public synchronized void entraGato() throws InterruptedException {
        while ((numPerros == 3 && numGatos == 1) || (numPerros == 1 && numGatos == 3)) {
            wait();
        }
        numGatos++;

    }

    public synchronized void saleGato() {
        numGatos--;
        notifyAll();
    }
}
