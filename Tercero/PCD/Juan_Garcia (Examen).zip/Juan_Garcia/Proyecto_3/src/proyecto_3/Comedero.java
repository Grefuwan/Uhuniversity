package proyecto_3;

import java.util.concurrent.locks.ReadWriteLock;
import java.util.concurrent.locks.ReentrantReadWriteLock;

public class Comedero {

    int numPerros = 0, numGatos = 0;

    ReadWriteLock colaPerros = new ReentrantReadWriteLock();
    ReadWriteLock colaGatos = new ReentrantReadWriteLock();

    //Condition colaPerros = mutex.writeLock().newCondition();
    //Condition colaGatos = mutex.readLock().newCondition();
    public void entraPerro() throws InterruptedException {
        colaPerros.writeLock().lock();

        while ((numPerros == 3 && numGatos == 1) || (numPerros == 1 && numGatos == 3)) {
            colaPerros.wait();
        }
        numPerros++;

    }

    public void salePerro() {

        numPerros--;
        if ((numPerros <= 2 && numGatos == 0) || (numPerros == 3 && numGatos == 0) || (numPerros == 0 && numGatos <= 2)) {
            colaPerros.writeLock().unlock();
        } else if ((numGatos <= 2 && numPerros == 0) || (numGatos == 3 && numPerros == 0) || (numGatos == 0 && numPerros <= 2)) {
            colaGatos.readLock().unlock();
        }

    }

    public void entraGato() throws InterruptedException {
        colaGatos.readLock().lock();

        while ((numPerros == 3 && numGatos == 1) || (numPerros == 1 && numGatos == 3)) {
            colaGatos.wait();
        }
        numGatos++;

    }

    public void saleGato() {

        numGatos--;
        if ((numGatos <= 2 && numPerros == 0) || (numGatos == 3 && numPerros == 0) || (numGatos == 0 && numPerros <= 2)) {
            colaGatos.readLock().unlock();
        } else if ((numPerros <= 2 && numGatos == 0) || (numPerros == 3 && numGatos == 0) || (numPerros == 0 && numGatos <= 2)) {
            colaPerros.writeLock().unlock();
        }

    }
}
