package proyecto_2;

import java.util.concurrent.locks.Condition;
import java.util.concurrent.locks.Lock;
import java.util.concurrent.locks.ReentrantLock;

public class Comedero {

    int numPerros = 0, numGatos = 0;

    Lock mutex = new ReentrantLock();
    Condition colaPerros = mutex.newCondition();
    Condition colaGatos = mutex.newCondition();

    public void entraPerro() throws InterruptedException {
        mutex.lock();
        try {
            while ((numPerros == 3 && numGatos == 1) || (numPerros == 1 && numGatos == 3)) {
                colaPerros.await();
            }
            numPerros++;
        } finally {
            mutex.unlock();
        }

    }

    public void salePerro() {
        mutex.lock();
        try {
            numPerros--;
            if ((numPerros <= 2 && numGatos == 0) || (numPerros == 3 && numGatos == 0) || (numPerros == 0 && numGatos <= 2)) {
                colaPerros.signal();
            } else if ((numGatos <= 2 && numPerros == 0) || (numGatos == 3 && numPerros == 0) || (numGatos == 0 && numPerros <= 2)) {
                colaGatos.signal();
            }

        } finally {
            mutex.unlock();
        }

    }

    public void entraGato() throws InterruptedException {
        mutex.lock();
        try {
            while ((numPerros == 3 && numGatos == 1) || (numPerros == 1 && numGatos == 3)) {
                colaGatos.await();
            }
            numGatos++;
        } finally {
            mutex.unlock();
        }

    }

    public void saleGato() {
        mutex.lock();
        try {
            numGatos--;
            if ((numGatos <= 2 && numPerros == 0) || (numGatos == 3 && numPerros == 0) || (numGatos == 0 && numPerros <= 2)) {
                colaGatos.signal();
            } else if ((numPerros <= 2 && numGatos == 0) || (numPerros == 3 && numGatos == 0) || (numPerros == 0 && numGatos <= 2)) {
                colaPerros.signal();
            }
        } finally {
            mutex.unlock();
        }

    }
}
