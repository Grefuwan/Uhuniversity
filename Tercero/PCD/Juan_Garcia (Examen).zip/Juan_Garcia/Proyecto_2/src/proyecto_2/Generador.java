package proyecto_2;

import static java.lang.Thread.sleep;
import java.util.Random;

public class Generador {

    public static void main(String[] args) throws InterruptedException {
        int numAnimales = 20;

        Random r = new Random();
        r.setSeed(System.currentTimeMillis());
        int prob;

        Thread[] animal = new Thread[numAnimales];
        Comedero com = new Comedero();

        for (int i = 0; i < numAnimales; i++) {
            prob = r.nextInt(10);
            sleep((r.nextInt(3) + 1) * 1000);
            if (prob < 5) {
                animal[i] = new Thread(new Perro(i, com));
            } else {
                animal[i] = new Thread(new Gato(i, com));
            }

            animal[i].start();
        }

        for (int i = 0; i < numAnimales; i++) {
            animal[i].join();
        }
    }

}
